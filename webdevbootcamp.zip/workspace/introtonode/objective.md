intro to node


*what is node
*why are we learning it
