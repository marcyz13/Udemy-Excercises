var knockknock = require("knock-knock-jokes")

console.log(knockknock())